# lumix-smart-lamp
IED Mini Project
